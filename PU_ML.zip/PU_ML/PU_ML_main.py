import pandas as pd
import subprocess
import os
import numpy as np
import random


root='./PU_data' #Path where CGCNN fitting data is stored
n_loop=2 #Number of CGCNN iterations

data=pd.read_csv(root+'/info.csv')
data0=data[data['class']==0]
data1=data[data['class']==1]
data1 = data1[:20]####for test
data0 = data0[:40]####for test


os.system('mkdir PU_result')
#####Train n_loop CGCNN models#####
for i_loop in range(n_loop):
    #Split data
    data1_train = data1
    data0_train = data0.sample(n=len(data1))
    data0_predict=data0.drop(data0[data0.id.isin(data0_train.id)].index)
    data0_predict['class']=list(np.zeros(len(data0_predict)-10))+list(np.ones(10))####Add categories in predict to avoid CGCNN runtime errors
    data_train=pd.concat([data1_train,data0_train])
    data_train = data_train.sample(frac=1, random_state=42).reset_index(drop=True)#Shuffle the dataset
    data_train.to_csv(root+'/id_prop.csv',index=None,header=None)
    data0_predict.to_csv('PU_result/predict{}.csv'.format(i_loop), index=None, header=None)

    #Train CGCNN model
    input_data='--train-ratio 0.6 --val-ratio 0.2 --test-ratio 0.2'
    result=subprocess.run(['python', 'cgcnn_main.py',
                           '--task', 'classification','--epochs','30',
                           '--train-ratio','0.6','--val-ratio','0.2','--test-ratio', '0.2',
                           root], capture_output=True)
    #python main.py --task classification --train-ratio 0.6 --val-ratio 0.2 --test-ratio 0.2 --epochs 30 data/sample-classification
    output_data=result.stdout
    print('loop: ',i_loop)  #########
    print(output_data)####

    #Save data results for i_loop
    
    os.system('cp {}/id_prop.csv PU_result/id_prop{}.csv'.format(root,i_loop))#Change cp to mv
    os.system('mv checkpoint.pth.tar PU_result/checkpoint{}.pth.tar'.format(i_loop))
    os.system('mv model_best.pth.tar PU_result/model_best{}.pth.tar'.format(i_loop))


#####Predict n_loop predict datasets#####
def change_id_prop(csv_path):
    '''Change part of class 0 to 1 to avoid inability to calculate due to all zeros'''

    # Read CSV file without header and name columns
    df = pd.read_csv(csv_path, header=None, names=['name', 'class'])
    # Assume we want to change the first 100 zeros in the second column to 1
    num_to_change = 5#############
    # Find indexes of the first 100 zeros
    indexes_to_change = df[df['class'] == 0].head(num_to_change).index
    # Change the classification type corresponding to these indexes to 1
    df.loc[indexes_to_change, 'class'] = 1
    # Save the modified DataFrame back to CSV file without header
    df.to_csv(csv_path, index=False, header=False)

for i_loop in range(n_loop):
    os.system('cp PU_result/predict{}.csv {}/id_prop.csv'.format(i_loop,root))
    change_id_prop('{}/id_prop.csv'.format(root))
    os.system('cp PU_result/checkpoint{}.pth.tar ./checkpoint.pth.tar'.format(i_loop))
    os.system('cp PU_result/model_best{}.pth.tar ./model_best.pth.tar'.format(i_loop))

    #Predict on predict dataset
    result=subprocess.run(['python', 'cgcnn_predict.py',
                               './model_best.pth.tar',
                               root], capture_output=True)
    output_data=result.stdout
    print('loop: ',i_loop)  #########
    print(output_data)####
    #Save prediction results for i_loop
    os.system('mv test_results.csv PU_result/predicted_results{}.csv'.format(i_loop))


#####Statistics on predicted results#####
data=[]
for i_loop in range(n_loop):
    data_i=pd.read_csv('PU_result/predicted_results{}.csv'.format(i_loop),names=['id','class','score'],header=None)
    data.append(data_i)
data=pd.concat(data)
# print(data)

ids=[]
scores=[]
for id in list(set(data['id'].values)):
    data_id=data[data['id']==id]
    score=data_id['score'].mean()
    ids.append(id)
    scores.append(score)
scores = np.array(scores)
scores = (scores - scores.min()) / (scores.max() - scores.min()) #Normalize scores to [0,1]
data_score=pd.DataFrame({'id':ids,'score':scores}).sort_values(by='score', ascending=False)
data_score.to_csv('./data_score.csv',index=None)